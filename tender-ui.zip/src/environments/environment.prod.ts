export const environment = {
  production: true,
  //local connectins
  BaseUrl: '192.168.1.150', //local - 192.168.1.200

  //live connections

  // BaseUrl: 'api.tender.peacocktech.in', //domain name -  tender.peacocktech.in

  PORT: 6001, // default
  // PORT: 9928, // tender.peacocktech.in
  PORT1: 4002,// default

};
