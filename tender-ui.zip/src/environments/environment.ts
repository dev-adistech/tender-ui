// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // local connectins
  BaseUrl: '192.168.1.150', //local - 192.168.1.102

  //live connections
  // BaseUrl: 'api.tender.peacocktech.in', //domain name -  tender.peacocktech.in // 9928


  //PORTS

  PORT: 6001, // default
  // PORT: 9928, // tender.peacocktech.in
  PORT1: 4002,// default
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
