import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import SignaturePad from 'signature_pad';
// declare var SignaturePad;
import { TendarEstService } from 'src/app/Service/Rap/tendar-est.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mini-paint',
  templateUrl: './mini-paint.component.html',
  styleUrls: ['./mini-paint.component.css']
})
export class MiniPaintComponent implements OnInit {

  @ViewChild('lienzo') lienzo: any;
  private signature: any;
  color = "#000000";
  radio = 2;

  NEWIMAGE:any = ''
  image = new Image();


  ngAfterViewInit(){
    let li = this.lienzo.nativeElement;
    li.width = 1000;
    this.signature = new SignaturePad(li, { backgroundColor: 'white' });

    let NewObj = {
      COMP_CODE: this.data['COMP_CODE'],
      DETID:this.data['DETID'],
      SRNO: this.data['SRNO'],
    }
    this.TendarEstServ.TendarVidUploadDisp(NewObj).subscribe((NewRes)=>{
      try{
        if(NewRes.success == true){
          this.NEWIMAGE = NewRes.data[0].PRN
          const imageUrl = this.NEWIMAGE;

        fetch(imageUrl)
      .then(response => response.blob())
      .then(blob => createImageBitmap(blob))
      .then(imageBitmap => {
        // Draw the ImageBitmap on the canvas
        const canvas = document.getElementById('lienzo') as HTMLCanvasElement;
        const context = canvas.getContext('2d');
        canvas.width = 1000;
        canvas.height = imageBitmap.height;
        context.drawImage(imageBitmap, 0, 0);
      })
      .catch(error => {
        console.error('Error fetching or drawing image:', error);
      });
        }
      } catch (error){
        this.spinner.hide()
      }
    })

    this.cambiarColor();
    this.changeRadio();

}

borrar(){
  this.signature.clear();
}

cambiarColor(){
  this.signature.penColor = this.color;
}

changeRadio(){
this.signature.dotSize = this.radio / 2;
this.signature.minWidth = this.radio / 2;
this.signature.maxWidth = this.radio;
}

data: any[] = []
  constructor(
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private TendarEstServ: TendarEstService,
    private http: HttpClient,
    @Inject(MAT_DIALOG_DATA) public dataMain: any,
    private _mdr: MatDialogRef<MiniPaintComponent>
  ) { 
    this.data = dataMain
  }

  ngOnInit(): void {
  }

  CLOSE(){
   this._mdr.close()
  }
  
download(){
  let a = document.getElementById('lienzo');
  // a.href = this.signature.toDataURL();
  let NEWDATA = this.data
  let op = this
    let selectedFile
          selectedFile = op.signature.toDataURL();
          if (selectedFile) {
            const file = selectedFile
            const blob = new Blob([file], { type: "image/png" });
            const fileReader = new FileReader();
            fileReader.readAsDataURL(blob);
            fileReader.addEventListener("load", () => {
              let base64String = fileReader.result;
              let FileObj = {
                FileName: `${this.data['COMP_CODE']}-${this.data['DETID']}-${this.data['SRNO']}-D`,
                base64File: selectedFile, //base64String
              };
              if (typeof base64String === "string") {
                op.uploadVideo(FileObj);
              } else {
                const bytes = new Uint8Array(base64String);
                base64String = String.fromCharCode.apply(null, bytes);
                op.uploadVideo(FileObj);
              }
              op.spinner.show()
              op.uploadVideo(FileObj).subscribe((response) => {
                try {
                  let Obj = {
                    COMP_CODE: this.data['COMP_CODE'],
                    DETID:this.data['DETID'],
                    SRNO: this.data['SRNO'],
                    SECURE_URL: response.data.secure_url,
                    URL: response.data.url,
                    CLOUDID: response.data.cloudid,
                    PUBLICID: response.data.public_id,
                    I_TYPE:'PRINT'
                  };
                  op.TendarEstServ.TendarVidUpload(Obj).subscribe((Res) => {
                    try {
                      if (Res.success == true) {
                        op.spinner.hide();
                        op.toastr.success("File uploaded succesfully.");
                      } else {
                        op.spinner.hide();
                        Swal.fire({
                          icon: "error",
                          title: "Oops...",
                          text: JSON.stringify(Res.data),
                        });
                      }
                    } catch (error) {
                      op.spinner.hide();
                      console.log(error);
      
                      op.toastr.error(error);
                    }
                  });
                } catch (error) {
                  op.spinner.hide();
                  console.log(error);
      
                  op.toastr.error(error);
                }
              });
            });
          }
       
  // a.download = 'picture.png';
  // a.click();
}
uploadVideo(FileObj): Observable<any> {
  const httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      projectId: "63ab279447964464e2194563",
      companyId: "63ab2411a95148bc211212fc",
    }),
  };

  return this.http.post(
    "https://cloud.peacocktech.in/api/PublicAPI/uploadFileOnCloud",
    FileObj,
    httpOptions
  );
}

async DELETE(){
  let Obj = {
    COMP_CODE: this.data['COMP_CODE'],
    DETID: this.data['DETID'],
    FSRNO: this.data['SRNO'],
    TSRNO: this.data['SRNO'],
    I_TYPE:"PRINT"
  };
  this.spinner.show()
  await this.TendarEstServ.TendarVidDisp(Obj).subscribe((Res) => {
    try {
      if (Res.success == true) {
        this.spinner.hide();

        const videos = Res.data.map((item) => item.PUBLICID);
        this.deleteTenderVideoFromCloud(videos);
      } else {
        this.toastr.warning("Cannot get video upload data.");
      }
    } catch (error) {
      console.log(error);

      this.spinner.hide();
      this.toastr.error(error);
    }
  });
  this.spinner.show()
  await this.TendarEstServ.TendarVidDelete(Obj).subscribe((Res) => {
    try {
      if (Res.success == true) {
        this.spinner.hide();
        this.toastr.success("Image deleted successfully.");
      } else {
        this.spinner.hide();
        this.toastr.warning("Something went wrong while deleting image.");
      }
    } catch (error) {
      console.log(error);

      this.spinner.hide();
      this.toastr.error(error);
    }
  });
}

async deleteTenderVideoFromCloud(videos) {
  // for (const video of videos) {
  for (let i = 0; i < videos.length; i++) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        projectId: "63ab279447964464e2194563",
        companyId: "63ab2411a95148bc211212fc",
        cloudid: "63abee53a3d3a783c330d74d",
      }),
      body: {
        FileName: videos[i],
        resource_type: "image",
      },
    };

    await this.http
      .request(
        "DELETE",
        "https://cloud.peacocktech.in/api/PublicAPI/uploadedFileDeleteOnCloud",
        httpOptions
      )
      .subscribe((Res) => {
        // if (i === videos.length - 1) this.deleteTenderVideoFromDatabase();
      });
  }
}

}
